<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @atp/partials/header.html.twig */
class __TwigTemplate_45d08d78122768073a44f5db4ce354a1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 14
        yield "
<div class=\"preloader\">
\t<div class=\"logo-container\"><!-- Using a placeholder logo with your color -->
\t\t<!-- <div class=\"atp__pr\">
\t\t            ATP
\t\t            </div> -->
\t</div>
\t<div class=\"spinner\"><img class=\"two--sc--img\" src=\"/themes/custom/atp/atp/assets/images/logo.png\"></div>
\t<!-- <p class=\"loading-text\">LOADING</p>
\t        <div class=\"progress-bar\">
\t            <div class=\"progress\"></div>
\t        </div> -->
</div>
<header class=\"header-inside\" id=\"header-inside\">
\t<nav class=\"navbar navbar-expand-lg\">
\t\t<div class=\"container\">
\t\t\t<a class=\"navbar-brand logo__1\" href=\"";
        // line 30
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("<front>"));
        yield "\">
\t\t\t\t<img class=\"two--sc--img\" src=\"/themes/custom/atp/atp/assets/images/logo.png\"></a>
\t\t\t<a class=\"navbar-brand logo__2\" href=\"";
        // line 32
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("<front>"));
        yield "\">
\t\t\t\t<img class=\"two--sc--img\" src=\"/themes/custom/atp/atp/assets/images/logo-2.png\"></a>
\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarNav\">
\t\t\t\t<span class=\"navbar-toggler-icon\"></span>
\t\t\t</button>
\t\t\t<div class=\"collapse navbar-collapse\" id=\"navbarNav\">
\t\t\t\t";
        // line 53
        yield "        \t";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "primary_menu", [], "any", false, false, true, 53)) {
            // line 54
            yield "\t\t\t\t";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "primary_menu", [], "any", false, false, true, 54), "html", null, true);
            yield "
\t\t\t";
        }
        // line 56
        yield "\t\t\t</div>
\t\t\t<div class=\"right--contact-multi-langue\">
\t\t\t\t<div class=\"d-flex align-items-center gap-3\">

\t\t\t\t\t\t";
        // line 72
        yield "            ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Drupal\twig_tweak\TwigTweakExtension::drupalEntity("block", "atp_languageswitcher"), "html", null, true);
        yield "

\t\t\t\t\t<button class=\"btn btn-contact\">
\t\t\t\t\t\t<a class=\"show_fr_page\" href=\"/fr/Contactez-nous\">
\t\t\t\t\t\t\t<span class=\"contact-text\">";
        // line 76
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Contact"));
        yield "</span>
\t\t\t\t\t\t\t<span class=\"contact-icon\">
\t\t\t\t\t\t\t\t<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"28\" height=\"28\" viewbox=\"0 0 28 28\" fill=\"none\">
\t\t\t\t\t\t\t\t\t<rect width=\"28\" height=\"28\" rx=\"14\" fill=\"#600100\"/>
\t\t\t\t\t\t\t\t\t<g clip-path=\"url(#clip0_6230_84)\">
\t\t\t\t\t\t\t\t\t\t<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M14.3802 6.13867C14.3802 7.098 14.5514 8.04792 14.8841 8.93422C15.2168 9.82052 15.7044 10.6258 16.3191 11.3042C16.9338 11.9825 17.6635 12.5206 18.4667 12.8877C19.2698 13.2548 20.1307 13.4438 21 13.4438V13.4748H21V14.5248H21V14.5557C20.1307 14.5557 19.2698 14.7447 18.4667 15.1118C17.6635 15.4789 16.9338 16.017 16.3191 16.6954C15.7044 17.3737 15.2168 18.179 14.8841 19.0653C14.5514 19.9516 14.3802 20.9015 14.3802 21.8609H13.3067C13.3067 17.8982 15.745 15.2686 19.0285 14.5248L7 14.5248L7 13.4748L19.0286 13.4748C15.745 12.731 13.3067 10.1014 13.3067 6.13867H14.3802Z\" fill=\"#FAFFF4\"/>
\t\t\t\t\t\t\t\t\t</g>
\t\t\t\t\t\t\t\t\t<defs>
\t\t\t\t\t\t\t\t\t\t<clipPath id=\"clip0_6230_84\">
\t\t\t\t\t\t\t\t\t\t\t<rect width=\"14\" height=\"14\" fill=\"white\" transform=\"translate(7 7)\"/>
\t\t\t\t\t\t\t\t\t\t</clipPath>
\t\t\t\t\t\t\t\t\t</defs>
\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</a>
            ";
        // line 92
        yield "            <a class=\"show_en_page\" href=\"/en/Contactez-nous\">
\t\t\t\t\t\t\t<span class=\"contact-text\">";
        // line 93
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Contact"));
        yield "</span>
\t\t\t\t\t\t\t<span class=\"contact-icon\">
\t\t\t\t\t\t\t\t<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"28\" height=\"28\" viewbox=\"0 0 28 28\" fill=\"none\">
\t\t\t\t\t\t\t\t\t<rect width=\"28\" height=\"28\" rx=\"14\" fill=\"#600100\"/>
\t\t\t\t\t\t\t\t\t<g clip-path=\"url(#clip0_6230_84)\">
\t\t\t\t\t\t\t\t\t\t<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M14.3802 6.13867C14.3802 7.098 14.5514 8.04792 14.8841 8.93422C15.2168 9.82052 15.7044 10.6258 16.3191 11.3042C16.9338 11.9825 17.6635 12.5206 18.4667 12.8877C19.2698 13.2548 20.1307 13.4438 21 13.4438V13.4748H21V14.5248H21V14.5557C20.1307 14.5557 19.2698 14.7447 18.4667 15.1118C17.6635 15.4789 16.9338 16.017 16.3191 16.6954C15.7044 17.3737 15.2168 18.179 14.8841 19.0653C14.5514 19.9516 14.3802 20.9015 14.3802 21.8609H13.3067C13.3067 17.8982 15.745 15.2686 19.0285 14.5248L7 14.5248L7 13.4748L19.0286 13.4748C15.745 12.731 13.3067 10.1014 13.3067 6.13867H14.3802Z\" fill=\"#FAFFF4\"/>
\t\t\t\t\t\t\t\t\t</g>
\t\t\t\t\t\t\t\t\t<defs>
\t\t\t\t\t\t\t\t\t\t<clipPath id=\"clip0_6230_84\">
\t\t\t\t\t\t\t\t\t\t\t<rect width=\"14\" height=\"14\" fill=\"white\" transform=\"translate(7 7)\"/>
\t\t\t\t\t\t\t\t\t\t</clipPath>
\t\t\t\t\t\t\t\t\t</defs>
\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t</button>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</nav>
</header>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@atp/partials/header.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  120 => 93,  117 => 92,  99 => 76,  91 => 72,  85 => 56,  79 => 54,  76 => 53,  67 => 32,  62 => 30,  44 => 14,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{# <header class=\"bg-white shadow-sm header--menu\" data-sticky-class=\"is-sticky\">
\t<nav class=\"navbar navbar-expand-lg navbar-light container\">
\t\t{{ drupal_entity('block','cfc_identitedusite') }}
\t\t<button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarNav\" aria-controls=\"navbarNav\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
\t\t\t<span class=\"navbar-toggler-icon\"></span>
\t\t</button>
\t\t<div class=\"collapse navbar-collapse\" id=\"navbarNav\">
\t\t\t{% if page.primary_menu %}
\t\t\t\t{{page.primary_menu}}
\t\t\t{% endif %}
\t\t</div>
\t</nav>
</header> #}

<div class=\"preloader\">
\t<div class=\"logo-container\"><!-- Using a placeholder logo with your color -->
\t\t<!-- <div class=\"atp__pr\">
\t\t            ATP
\t\t            </div> -->
\t</div>
\t<div class=\"spinner\"><img class=\"two--sc--img\" src=\"/themes/custom/atp/atp/assets/images/logo.png\"></div>
\t<!-- <p class=\"loading-text\">LOADING</p>
\t        <div class=\"progress-bar\">
\t            <div class=\"progress\"></div>
\t        </div> -->
</div>
<header class=\"header-inside\" id=\"header-inside\">
\t<nav class=\"navbar navbar-expand-lg\">
\t\t<div class=\"container\">
\t\t\t<a class=\"navbar-brand logo__1\" href=\"{{ path('<front>') }}\">
\t\t\t\t<img class=\"two--sc--img\" src=\"/themes/custom/atp/atp/assets/images/logo.png\"></a>
\t\t\t<a class=\"navbar-brand logo__2\" href=\"{{ path('<front>') }}\">
\t\t\t\t<img class=\"two--sc--img\" src=\"/themes/custom/atp/atp/assets/images/logo-2.png\"></a>
\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarNav\">
\t\t\t\t<span class=\"navbar-toggler-icon\"></span>
\t\t\t</button>
\t\t\t<div class=\"collapse navbar-collapse\" id=\"navbarNav\">
\t\t\t\t{# <ul class=\"navbar-nav ms-auto\">
\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"/index.html\">Accueil</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"/Our_hestory.html\">Agence</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"/Nos_projets.html\">Projets</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"/carriere.html\">Carrières</a>
\t\t\t\t\t</li>

\t\t\t\t</ul> #}
        \t{% if page.primary_menu %}
\t\t\t\t{{page.primary_menu}}
\t\t\t{% endif %}
\t\t\t</div>
\t\t\t<div class=\"right--contact-multi-langue\">
\t\t\t\t<div class=\"d-flex align-items-center gap-3\">

\t\t\t\t\t\t{# <button class=\"btn btn-lang dropdown-toggle\" type=\"button\" id=\"langDropdown\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\">FR</button>
\t\t\t\t\t\t<ul class=\"dropdown-menu\" aria-labelledby=\"langDropdown\">
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#\">EN</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#\">ES</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#\">DE</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul> #}
            {{ drupal_entity('block','atp_languageswitcher') }}

\t\t\t\t\t<button class=\"btn btn-contact\">
\t\t\t\t\t\t<a class=\"show_fr_page\" href=\"/fr/Contactez-nous\">
\t\t\t\t\t\t\t<span class=\"contact-text\">{{'Contact'|t}}</span>
\t\t\t\t\t\t\t<span class=\"contact-icon\">
\t\t\t\t\t\t\t\t<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"28\" height=\"28\" viewbox=\"0 0 28 28\" fill=\"none\">
\t\t\t\t\t\t\t\t\t<rect width=\"28\" height=\"28\" rx=\"14\" fill=\"#600100\"/>
\t\t\t\t\t\t\t\t\t<g clip-path=\"url(#clip0_6230_84)\">
\t\t\t\t\t\t\t\t\t\t<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M14.3802 6.13867C14.3802 7.098 14.5514 8.04792 14.8841 8.93422C15.2168 9.82052 15.7044 10.6258 16.3191 11.3042C16.9338 11.9825 17.6635 12.5206 18.4667 12.8877C19.2698 13.2548 20.1307 13.4438 21 13.4438V13.4748H21V14.5248H21V14.5557C20.1307 14.5557 19.2698 14.7447 18.4667 15.1118C17.6635 15.4789 16.9338 16.017 16.3191 16.6954C15.7044 17.3737 15.2168 18.179 14.8841 19.0653C14.5514 19.9516 14.3802 20.9015 14.3802 21.8609H13.3067C13.3067 17.8982 15.745 15.2686 19.0285 14.5248L7 14.5248L7 13.4748L19.0286 13.4748C15.745 12.731 13.3067 10.1014 13.3067 6.13867H14.3802Z\" fill=\"#FAFFF4\"/>
\t\t\t\t\t\t\t\t\t</g>
\t\t\t\t\t\t\t\t\t<defs>
\t\t\t\t\t\t\t\t\t\t<clipPath id=\"clip0_6230_84\">
\t\t\t\t\t\t\t\t\t\t\t<rect width=\"14\" height=\"14\" fill=\"white\" transform=\"translate(7 7)\"/>
\t\t\t\t\t\t\t\t\t\t</clipPath>
\t\t\t\t\t\t\t\t\t</defs>
\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</a>
            {#  #}
            <a class=\"show_en_page\" href=\"/en/Contactez-nous\">
\t\t\t\t\t\t\t<span class=\"contact-text\">{{'Contact'|t}}</span>
\t\t\t\t\t\t\t<span class=\"contact-icon\">
\t\t\t\t\t\t\t\t<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"28\" height=\"28\" viewbox=\"0 0 28 28\" fill=\"none\">
\t\t\t\t\t\t\t\t\t<rect width=\"28\" height=\"28\" rx=\"14\" fill=\"#600100\"/>
\t\t\t\t\t\t\t\t\t<g clip-path=\"url(#clip0_6230_84)\">
\t\t\t\t\t\t\t\t\t\t<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M14.3802 6.13867C14.3802 7.098 14.5514 8.04792 14.8841 8.93422C15.2168 9.82052 15.7044 10.6258 16.3191 11.3042C16.9338 11.9825 17.6635 12.5206 18.4667 12.8877C19.2698 13.2548 20.1307 13.4438 21 13.4438V13.4748H21V14.5248H21V14.5557C20.1307 14.5557 19.2698 14.7447 18.4667 15.1118C17.6635 15.4789 16.9338 16.017 16.3191 16.6954C15.7044 17.3737 15.2168 18.179 14.8841 19.0653C14.5514 19.9516 14.3802 20.9015 14.3802 21.8609H13.3067C13.3067 17.8982 15.745 15.2686 19.0285 14.5248L7 14.5248L7 13.4748L19.0286 13.4748C15.745 12.731 13.3067 10.1014 13.3067 6.13867H14.3802Z\" fill=\"#FAFFF4\"/>
\t\t\t\t\t\t\t\t\t</g>
\t\t\t\t\t\t\t\t\t<defs>
\t\t\t\t\t\t\t\t\t\t<clipPath id=\"clip0_6230_84\">
\t\t\t\t\t\t\t\t\t\t\t<rect width=\"14\" height=\"14\" fill=\"white\" transform=\"translate(7 7)\"/>
\t\t\t\t\t\t\t\t\t\t</clipPath>
\t\t\t\t\t\t\t\t\t</defs>
\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t</button>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</nav>
</header>
{# <header class=\"bg-white shadow-sm header--menu\" data-sticky-class=\"is-sticky\">
    <div class=\"top_header\">

       {{ drupal_entity('block','atp_languageswitcher') }}
    </div>
    <nav class=\"navbar navbar-expand-lg navbar-light menu_principe\">
      <div class=\"container\">

        {{ drupal_entity('block','desktech_site_branding') }}
        <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarScroll\"
          aria-controls=\"navbarScroll\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
          <span class=\"navbar-toggler-icon\"></span>
        </button>
        <div class=\"collapse navbar-collapse\" id=\"navbarScroll\">


\t{% if page.primary_menu %}
\t\t\t\t{{page.primary_menu}}
\t\t\t{% endif %}
        </div>
      </div>
    </nav>
  </header> #}
", "@atp/partials/header.html.twig", "C:\\laragon\\www\\atp\\themes\\custom\\atp\\templates\\partials\\header.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 53];
        static $filters = ["escape" => 54, "t" => 76];
        static $functions = ["path" => 30, "drupal_entity" => 72];

        try {
            $this->sandbox->checkSecurity(
                ['if'],
                ['escape', 't'],
                ['path', 'drupal_entity'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
