<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/atp/templates/view/projets/views-view--projets--page-1.html.twig */
class __TwigTemplate_0c7ac4888316a82e487da54cf768c46c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 35
        yield "<section class=\"sc---prj-1\">
\t<div class=\"container\">
\t\t<div class=\"intro-text title--sc\">
    ";
        // line 38
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Drupal\twig_tweak\TwigTweakExtension::drupalEntity("block", "atp_nosprojetstitre"), "html", null, true);
        yield "

\t\t</div>

\t\t<div class=\"sc---prj-2-filter\">
\t\t\t<div
\t\t\t\tclass=\"row\">
\t\t\t\t";
        // line 46
        yield "\t\t\t\t";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["exposed"] ?? null), "html", null, true);
        yield "
\t\t\t\t";
        // line 76
        yield "
\t\t\t</div>
\t\t</div>

\t</div>
</section>

<section class=\"section--4\">
\t<div class=\"container\">

\t\t<div class=\"row\">

\t\t\t";
        // line 88
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["rows"] ?? null), "html", null, true);
        yield "
\t\t\t";
        // line 246
        yield "\t\t</div>

\t\t<div class=\"text-center pagination_pager\">
\t\t\t";
        // line 249
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["pager"] ?? null), "html", null, true);
        yield "

\t\t</div>
\t</div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["exposed", "rows", "pager"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/atp/templates/view/projets/views-view--projets--page-1.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  87 => 249,  82 => 246,  78 => 88,  64 => 76,  59 => 46,  49 => 38,  44 => 35,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Default theme implementation for main view template.
 *
 * Available variables:
 * - attributes: Remaining HTML attributes for the element.
 * - css_name: A CSS-safe version of the view name.
 * - css_class: The user-specified classes names, if any.
 * - header: The optional header.
 * - footer: The optional footer.
 * - rows: The results of the view query, if any.
 * - empty: The content to display if there are no rows.
 * - pager: The optional pager next/prev links to display.
 * - exposed: Exposed widget form/info to display.
 * - feed_icons: Optional feed icons to display.
 * - more: An optional link to the next page of results.
 * - title: Title of the view, only used when displaying in the admin preview.
 * - title_prefix: Additional output populated by modules, intended to be
 *   displayed in front of the view title.
 * - title_suffix: Additional output populated by modules, intended to be
 *   displayed after the view title.
 * - attachment_before: An optional attachment view to be displayed before the
 *   view content.
 * - attachment_after: An optional attachment view to be displayed after the
 *   view content.
 * - dom_id: Unique id for every view being printed to give unique class for
 *   JavaScript.
 *
 * @see template_preprocess_views_view()
 *
 * @ingroup themeable
 */
#}
<section class=\"sc---prj-1\">
\t<div class=\"container\">
\t\t<div class=\"intro-text title--sc\">
    {{ drupal_entity('block','atp_nosprojetstitre') }}

\t\t</div>

\t\t<div class=\"sc---prj-2-filter\">
\t\t\t<div
\t\t\t\tclass=\"row\">
\t\t\t\t{#  #}
\t\t\t\t{{ exposed }}
\t\t\t\t{# <div class=\"col-md-4\">
\t\t\t\t\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"Rechercher des projets par nom ou description\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-2 select__list\" id=\"select__list\">
\t\t\t\t\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t\t\t\t\t<div class=\"filter-label\">Lieu</div>
\t\t\t\t\t\t\t\t\t\t<select class=\"form-select\">
\t\t\t\t\t\t\t\t\t\t\t<option>Lieu</option>
\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-2 select__list\">
\t\t\t\t\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t\t\t\t\t<div class=\"filter-label\">Type</div>
\t\t\t\t\t\t\t\t\t\t<select class=\"form-select\">
\t\t\t\t\t\t\t\t\t\t\t<option>Type</option>
\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-2 select__list\">
\t\t\t\t\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t\t\t\t\t<div class=\"filter-label\">Etat</div>
\t\t\t\t\t\t\t\t\t\t<select class=\"form-select\">
\t\t\t\t\t\t\t\t\t\t\t<option>État</option>
\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div> #}

\t\t\t</div>
\t\t</div>

\t</div>
</section>

<section class=\"section--4\">
\t<div class=\"container\">

\t\t<div class=\"row\">

\t\t\t{{ rows }}
\t\t\t{# <div class=\"col-md-6 col-lg-4 mb-4\">
\t\t\t\t\t\t\t\t\t          <div class=\"project-card card\">
\t\t\t\t\t\t\t\t\t            <a href=\"#\">
\t\t\t\t\t\t\t\t\t              <img src=\"/themes/custom/atp/atp/assets/images/new2.png\" class=\"project-img card-img-top\" alt=\"Projet résidentiel\">
\t\t\t\t\t\t\t\t\t              <div class=\"card-body\">
\t\t\t\t\t\t\t\t\t                <div class=\"project-category\">Anfa prime hospital</div>
\t\t\t\t\t\t\t\t\t                <h3 class=\"project-title\">Résidence Horizon</h3>
\t\t\t\t\t\t\t\t\t                <p class=\"project-description\">Un complexe résidentiel de 80 unités intégrant des espaces verts et des
\t\t\t\t\t\t\t\t\t                  équipements communautaires.</p>
\t\t\t\t\t\t\t\t\t                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
\t\t\t\t\t\t\t\t\t                    viewBox=\"0 0 20 20\" fill=\"none\">
\t\t\t\t\t\t\t\t\t                    <path
\t\t\t\t\t\t\t\t\t                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
\t\t\t\t\t\t\t\t\t                      fill=\"white\" />
\t\t\t\t\t\t\t\t\t                  </svg>Terminé en 2021 </div>
\t\t\t\t\t\t\t\t\t              </div>
\t\t\t\t\t\t\t\t\t            </a>
\t\t\t\t\t\t\t\t\t          </div>
\t\t\t\t\t\t\t\t\t        </div>

\t\t\t\t\t\t\t\t\t        <div class=\"col-md-6 col-lg-4 mb-4\">
\t\t\t\t\t\t\t\t\t          <div class=\"project-card card\">
\t\t\t\t\t\t\t\t\t            <a href=\"#\">
\t\t\t\t\t\t\t\t\t              <img src=\"/themes/custom/atp/atp/assets/images/new3.png\" class=\"project-img card-img-top\" alt=\"Projet urbain\">
\t\t\t\t\t\t\t\t\t              <div class=\"card-body\">
\t\t\t\t\t\t\t\t\t                <div class=\"project-category\">MH CMNMC</div>
\t\t\t\t\t\t\t\t\t                <h3 class=\"project-title\">Parc Central</h3>
\t\t\t\t\t\t\t\t\t                <p class=\"project-description\">Réaménagement de 12 hectares en espace vert public avec installations
\t\t\t\t\t\t\t\t\t                  sportives et culturelles.</p>
\t\t\t\t\t\t\t\t\t                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
\t\t\t\t\t\t\t\t\t                    viewBox=\"0 0 20 20\" fill=\"none\">
\t\t\t\t\t\t\t\t\t                    <path
\t\t\t\t\t\t\t\t\t                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
\t\t\t\t\t\t\t\t\t                      fill=\"white\" />
\t\t\t\t\t\t\t\t\t                  </svg>Terminé en 2021 </div>
\t\t\t\t\t\t\t\t\t              </div>
\t\t\t\t\t\t\t\t\t            </a>
\t\t\t\t\t\t\t\t\t          </div>
\t\t\t\t\t\t\t\t\t        </div>
\t\t\t\t\t\t\t\t\t        <div class=\"col-md-6 col-lg-4 mb-4\">
\t\t\t\t\t\t\t\t\t          <div class=\"project-card card\">
\t\t\t\t\t\t\t\t\t            <a href=\"#\">
\t\t\t\t\t\t\t\t\t              <img src=\"/themes/custom/atp/atp/assets/images/new1.png\" class=\"project-img card-img-top\" alt=\"Projet architectural moderne\">
\t\t\t\t\t\t\t\t\t              <div class=\"card-body\">
\t\t\t\t\t\t\t\t\t                <div class=\"project-category\">Glass Tower Complex</div>
\t\t\t\t\t\t\t\t\t                <h3 class=\"project-title\">Tour Lumina</h3>
\t\t\t\t\t\t\t\t\t                <p class=\"project-description\">Une tour de 40 étages alliant durabilité et innovation technologique au
\t\t\t\t\t\t\t\t\t                  cœur du quartier d'affaires.</p>
\t\t\t\t\t\t\t\t\t                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
\t\t\t\t\t\t\t\t\t                    viewBox=\"0 0 20 20\" fill=\"none\">
\t\t\t\t\t\t\t\t\t                    <path
\t\t\t\t\t\t\t\t\t                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
\t\t\t\t\t\t\t\t\t                      fill=\"white\" />
\t\t\t\t\t\t\t\t\t                  </svg>Terminé en 2021 </div>
\t\t\t\t\t\t\t\t\t              </div>
\t\t\t\t\t\t\t\t\t            </a>
\t\t\t\t\t\t\t\t\t          </div>
\t\t\t\t\t\t\t\t\t        </div>

\t\t\t\t\t\t\t\t\t        <div class=\"col-md-6 col-lg-4 mb-4\">
\t\t\t\t\t\t\t\t\t          <div class=\"project-card card\">
\t\t\t\t\t\t\t\t\t            <a href=\"#\">
\t\t\t\t\t\t\t\t\t              <img src=\"/themes/custom/atp/atp/assets/images/new2.png\" class=\"project-img card-img-top\" alt=\"Projet résidentiel\">
\t\t\t\t\t\t\t\t\t              <div class=\"card-body\">
\t\t\t\t\t\t\t\t\t                <div class=\"project-category\">Anfa prime hospital</div>
\t\t\t\t\t\t\t\t\t                <h3 class=\"project-title\">Résidence Horizon</h3>
\t\t\t\t\t\t\t\t\t                <p class=\"project-description\">Un complexe résidentiel de 80 unités intégrant des espaces verts et des
\t\t\t\t\t\t\t\t\t                  équipements communautaires.</p>
\t\t\t\t\t\t\t\t\t                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
\t\t\t\t\t\t\t\t\t                    viewBox=\"0 0 20 20\" fill=\"none\">
\t\t\t\t\t\t\t\t\t                    <path
\t\t\t\t\t\t\t\t\t                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
\t\t\t\t\t\t\t\t\t                      fill=\"white\" />
\t\t\t\t\t\t\t\t\t                  </svg>Terminé en 2021 </div>
\t\t\t\t\t\t\t\t\t              </div>
\t\t\t\t\t\t\t\t\t            </a>
\t\t\t\t\t\t\t\t\t          </div>
\t\t\t\t\t\t\t\t\t        </div>

\t\t\t\t\t\t\t\t\t        <div class=\"col-md-6 col-lg-4 mb-4\">
\t\t\t\t\t\t\t\t\t          <div class=\"project-card card\">
\t\t\t\t\t\t\t\t\t            <a href=\"#\">
\t\t\t\t\t\t\t\t\t              <img src=\"/themes/custom/atp/atp/assets/images/new3.png\" class=\"project-img card-img-top\" alt=\"Projet urbain\">
\t\t\t\t\t\t\t\t\t              <div class=\"card-body\">
\t\t\t\t\t\t\t\t\t                <div class=\"project-category\">MH CMNMC</div>
\t\t\t\t\t\t\t\t\t                <h3 class=\"project-title\">Parc Central</h3>
\t\t\t\t\t\t\t\t\t                <p class=\"project-description\">Réaménagement de 12 hectares en espace vert public avec installations
\t\t\t\t\t\t\t\t\t                  sportives et culturelles.</p>
\t\t\t\t\t\t\t\t\t                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
\t\t\t\t\t\t\t\t\t                    viewBox=\"0 0 20 20\" fill=\"none\">
\t\t\t\t\t\t\t\t\t                    <path
\t\t\t\t\t\t\t\t\t                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
\t\t\t\t\t\t\t\t\t                      fill=\"white\" />
\t\t\t\t\t\t\t\t\t                  </svg>Terminé en 2021 </div>
\t\t\t\t\t\t\t\t\t              </div>
\t\t\t\t\t\t\t\t\t            </a>
\t\t\t\t\t\t\t\t\t          </div>
\t\t\t\t\t\t\t\t\t        </div>
\t\t\t\t\t\t\t\t\t        <div class=\"col-md-6 col-lg-4 mb-4\">
\t\t\t\t\t\t\t\t\t          <div class=\"project-card card\">
\t\t\t\t\t\t\t\t\t            <a href=\"#\">
\t\t\t\t\t\t\t\t\t              <img src=\"/themes/custom/atp/atp/assets/images/new1.png\" class=\"project-img card-img-top\" alt=\"Projet architectural moderne\">
\t\t\t\t\t\t\t\t\t              <div class=\"card-body\">
\t\t\t\t\t\t\t\t\t                <div class=\"project-category\">Glass Tower Complex</div>
\t\t\t\t\t\t\t\t\t                <h3 class=\"project-title\">Tour Lumina</h3>
\t\t\t\t\t\t\t\t\t                <p class=\"project-description\">Une tour de 40 étages alliant durabilité et innovation technologique au
\t\t\t\t\t\t\t\t\t                  cœur du quartier d'affaires.</p>
\t\t\t\t\t\t\t\t\t                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
\t\t\t\t\t\t\t\t\t                    viewBox=\"0 0 20 20\" fill=\"none\">
\t\t\t\t\t\t\t\t\t                    <path
\t\t\t\t\t\t\t\t\t                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
\t\t\t\t\t\t\t\t\t                      fill=\"white\" />
\t\t\t\t\t\t\t\t\t                  </svg>Terminé en 2021 </div>
\t\t\t\t\t\t\t\t\t              </div>
\t\t\t\t\t\t\t\t\t            </a>
\t\t\t\t\t\t\t\t\t          </div>
\t\t\t\t\t\t\t\t\t        </div>

\t\t\t\t\t\t\t\t\t        <div class=\"col-md-6 col-lg-4 mb-4\">
\t\t\t\t\t\t\t\t\t          <div class=\"project-card card\">
\t\t\t\t\t\t\t\t\t            <a href=\"#\">
\t\t\t\t\t\t\t\t\t              <img src=\"/themes/custom/atp/atp/assets/images/new2.png\" class=\"project-img card-img-top\" alt=\"Projet résidentiel\">
\t\t\t\t\t\t\t\t\t              <div class=\"card-body\">
\t\t\t\t\t\t\t\t\t                <div class=\"project-category\">Anfa prime hospital</div>
\t\t\t\t\t\t\t\t\t                <h3 class=\"project-title\">Résidence Horizon</h3>
\t\t\t\t\t\t\t\t\t                <p class=\"project-description\">Un complexe résidentiel de 80 unités intégrant des espaces verts et des
\t\t\t\t\t\t\t\t\t                  équipements communautaires.</p>
\t\t\t\t\t\t\t\t\t                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
\t\t\t\t\t\t\t\t\t                    viewBox=\"0 0 20 20\" fill=\"none\">
\t\t\t\t\t\t\t\t\t                    <path
\t\t\t\t\t\t\t\t\t                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
\t\t\t\t\t\t\t\t\t                      fill=\"white\" />
\t\t\t\t\t\t\t\t\t                  </svg>Terminé en 2021 </div>
\t\t\t\t\t\t\t\t\t              </div>
\t\t\t\t\t\t\t\t\t            </a>
\t\t\t\t\t\t\t\t\t          </div>
\t\t\t\t\t\t\t\t\t        </div>

\t\t\t\t\t\t\t\t\t        <div class=\"col-md-6 col-lg-4 mb-4\">
\t\t\t\t\t\t\t\t\t          <div class=\"project-card card\">
\t\t\t\t\t\t\t\t\t            <a href=\"#\">
\t\t\t\t\t\t\t\t\t              <img src=\"/themes/custom/atp/atp/assets/images/new3.png\" class=\"project-img card-img-top\" alt=\"Projet urbain\">
\t\t\t\t\t\t\t\t\t              <div class=\"card-body\">
\t\t\t\t\t\t\t\t\t                <div class=\"project-category\">MH CMNMC</div>
\t\t\t\t\t\t\t\t\t                <h3 class=\"project-title\">Parc Central</h3>
\t\t\t\t\t\t\t\t\t                <p class=\"project-description\">Réaménagement de 12 hectares en espace vert public avec installations
\t\t\t\t\t\t\t\t\t                  sportives et culturelles.</p>
\t\t\t\t\t\t\t\t\t                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
\t\t\t\t\t\t\t\t\t                    viewBox=\"0 0 20 20\" fill=\"none\">
\t\t\t\t\t\t\t\t\t                    <path
\t\t\t\t\t\t\t\t\t                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
\t\t\t\t\t\t\t\t\t                      fill=\"white\" />
\t\t\t\t\t\t\t\t\t                  </svg>Terminé en 2021 </div>
\t\t\t\t\t\t\t\t\t              </div>
\t\t\t\t\t\t\t\t\t            </a>
\t\t\t\t\t\t\t\t\t          </div>
\t\t\t\t\t\t\t\t\t        </div> #}
\t\t</div>

\t\t<div class=\"text-center pagination_pager\">
\t\t\t{{ pager }}

\t\t</div>
\t</div>
</section>
", "themes/custom/atp/templates/view/projets/views-view--projets--page-1.html.twig", "C:\\laragon\\www\\atp\\themes\\custom\\atp\\templates\\view\\projets\\views-view--projets--page-1.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["escape" => 38];
        static $functions = ["drupal_entity" => 38];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape'],
                ['drupal_entity'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
