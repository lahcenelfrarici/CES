<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/atp/templates/system/pager.html.twig */
class __TwigTemplate_2d7dc09af1493981dfa2f3652a8c432f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 34
        yield "

";
        // line 36
        if (($context["items"] ?? null)) {
            // line 37
            yield "  <nav class=\"mt-4 paginations-list text-center\">
    <div class=\"paginations-wp\">
      <div class=\"pagination-wp-lists\">
        <nav class=\"pager\" role=\"navigation\" aria-labelledby=\"";
            // line 40
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["heading_id"] ?? null), "html", null, true);
            yield "\">
          <ul class=\"pagination-success\">
            ";
            // line 43
            yield "            ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "first", [], "any", false, false, true, 43))) {
                // line 44
                yield "              ";
                $context["pageNumber"] = (Twig\Extension\CoreExtension::last($this->env->getCharset(), Twig\Extension\CoreExtension::split($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "first", [], "any", false, false, true, 44), "href", [], "any", false, false, true, 44), "=")) + 1);
                // line 45
                yield "              ";
                if (!CoreExtension::inFilter(($context["pageNumber"] ?? null), Twig\Extension\CoreExtension::keys(CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "pages", [], "any", false, false, true, 45)))) {
                    // line 46
                    yield "                ";
                    if ( !CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "first", [], "any", false, false, true, 46), "is_active", [], "any", false, false, true, 46)) {
                        // line 47
                        yield "                  <li class=\"page-item\">
                    <a href=\"";
                        // line 48
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "first", [], "any", false, false, true, 48), "href", [], "any", false, false, true, 48), "html", null, true);
                        yield "\" title=\"Go to page ";
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["pageNumber"] ?? null), "html", null, true);
                        yield "\">
                      <span class=\"visually-hidden\">Page</span>";
                        // line 49
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["pageNumber"] ?? null), "html", null, true);
                        yield "
                    </a>
                  </li>
                ";
                    }
                    // line 53
                    yield "              ";
                }
                // line 54
                yield "            ";
            }
            // line 55
            yield "
            ";
            // line 57
            yield "            ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["ellipses"] ?? null), "previous", [], "any", false, false, true, 57)) {
                // line 58
                yield "              <li class=\"page-item\">
                <span class=\"page-link dots\">...</span>
              </li>
            ";
            }
            // line 62
            yield "
            ";
            // line 64
            yield "            ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "pages", [], "any", false, false, true, 64));
            foreach ($context['_seq'] as $context["key"] => $context["item"]) {
                // line 65
                yield "              <li class=\"page-item";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($context["current"] ?? null) == $context["key"])) ? (" active") : ("")));
                yield "\">
                <a href=\"";
                // line 66
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, true, 66), "html", null, true);
                yield "\" title=\"";
                yield (((($context["current"] ?? null) == $context["key"])) ? ("Page courante") : ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("Go to page " . $context["key"]), "html", null, true)));
                yield "\">
                  ";
                // line 67
                if ((($context["current"] ?? null) == $context["key"])) {
                    // line 68
                    yield "                    <span class=\"visually-hidden\">Page courante</span>
                  ";
                } else {
                    // line 70
                    yield "                    <span class=\"visually-hidden\">Page</span>
                  ";
                }
                // line 72
                yield "                  ";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $context["key"], "html", null, true);
                yield "
                </a>
              </li>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['key'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 76
            yield "
            ";
            // line 78
            yield "            ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["ellipses"] ?? null), "next", [], "any", false, false, true, 78)) {
                // line 79
                yield "              <li class=\"page-item\">
                <span class=\"page-link dots\">...</span>
              </li>
            ";
            }
            // line 83
            yield "
            ";
            // line 85
            yield "            ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "last", [], "any", false, false, true, 85))) {
                // line 86
                yield "              ";
                $context["pageNumber"] = (Twig\Extension\CoreExtension::last($this->env->getCharset(), Twig\Extension\CoreExtension::split($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "last", [], "any", false, false, true, 86), "href", [], "any", false, false, true, 86), "=")) + 1);
                // line 87
                yield "              ";
                if (!CoreExtension::inFilter(($context["pageNumber"] ?? null), Twig\Extension\CoreExtension::keys(CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "pages", [], "any", false, false, true, 87)))) {
                    // line 88
                    yield "                ";
                    if ( !CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "last", [], "any", false, false, true, 88), "is_active", [], "any", false, false, true, 88)) {
                        // line 89
                        yield "                  <li class=\"page-item\">
                    <a href=\"";
                        // line 90
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["items"] ?? null), "last", [], "any", false, false, true, 90), "href", [], "any", false, false, true, 90), "html", null, true);
                        yield "\" title=\"Go to page ";
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["pageNumber"] ?? null), "html", null, true);
                        yield "\">
                      <span class=\"visually-hidden\">Page</span>";
                        // line 91
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["pageNumber"] ?? null), "html", null, true);
                        yield "
                    </a>
                  </li>
                ";
                    }
                    // line 95
                    yield "              ";
                }
                // line 96
                yield "            ";
            }
            // line 97
            yield "          </ul>
        </nav>
      </div>
    </div>
  </nav>
";
        }
        // line 103
        yield "
";
        // line 121
        yield "


";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["items", "heading_id", "ellipses", "current"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/atp/templates/system/pager.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  206 => 121,  203 => 103,  195 => 97,  192 => 96,  189 => 95,  182 => 91,  176 => 90,  173 => 89,  170 => 88,  167 => 87,  164 => 86,  161 => 85,  158 => 83,  152 => 79,  149 => 78,  146 => 76,  135 => 72,  131 => 70,  127 => 68,  125 => 67,  119 => 66,  114 => 65,  109 => 64,  106 => 62,  100 => 58,  97 => 57,  94 => 55,  91 => 54,  88 => 53,  81 => 49,  75 => 48,  72 => 47,  69 => 46,  66 => 45,  63 => 44,  60 => 43,  55 => 40,  50 => 37,  48 => 36,  44 => 34,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Theme override to display a pager.
 *
 * Available variables:
 * - heading_id: Pagination heading ID.
 * - items: List of pager items.
 *   The list is keyed by the following elements:
 *   - first: Item for the first page; not present on the first page of results.
 *   - previous: Item for the previous page; not present on the first page
 *     of results.
 *   - next: Item for the next page; not present on the last page of results.
 *   - last: Item for the last page; not present on the last page of results.
 *   - pages: List of pages, keyed by page number.
 *   Sub-sub elements:
 *   items.first, items.previous, items.next, items.last, and each item inside
 *   items.pages contain the following elements:
 *   - href: URL with appropriate query parameters for the item.
 *   - attributes: A keyed list of HTML attributes for the item.
 *   - text: The visible text used for the item link, such as \"‹ Previous\"
 *     or \"Next ›\".
 * - current: The page number of the current page.
 * - ellipses: If there are more pages than the quantity allows, then an
 *   ellipsis before or after the listed pages may be present.
 *   - previous: Present if the currently visible list of pages does not start
 *     at the first page.
 *   - next: Present if the visible list of pages ends before the last page.
 *
 * @see template_preprocess_pager()
 *
 */
#}


{% if items %}
  <nav class=\"mt-4 paginations-list text-center\">
    <div class=\"paginations-wp\">
      <div class=\"pagination-wp-lists\">
        <nav class=\"pager\" role=\"navigation\" aria-labelledby=\"{{ heading_id }}\">
          <ul class=\"pagination-success\">
            {# Print first item if we are not on the first page and it's not already included in the pages list. #}
            {% if items.first is not empty %}
              {% set pageNumber = items.first.href|split('=')|last + 1 %}
              {% if pageNumber not in items.pages|keys %}
                {% if not items.first.is_active %}
                  <li class=\"page-item\">
                    <a href=\"{{ items.first.href }}\" title=\"Go to page {{ pageNumber }}\">
                      <span class=\"visually-hidden\">Page</span>{{ pageNumber }}
                    </a>
                  </li>
                {% endif %}
              {% endif %}
            {% endif %}

            {# Add an ellipsis if there are further previous pages. #}
            {% if ellipses.previous %}
              <li class=\"page-item\">
                <span class=\"page-link dots\">...</span>
              </li>
            {% endif %}

            {# Generate the actual pager items. #}
            {% for key, item in items.pages %}
              <li class=\"page-item{{ current == key ? ' active' : '' }}\">
                <a href=\"{{ item.href }}\" title=\"{{ current == key ? 'Page courante' : 'Go to page ' ~ key }}\">
                  {% if current == key %}
                    <span class=\"visually-hidden\">Page courante</span>
                  {% else %}
                    <span class=\"visually-hidden\">Page</span>
                  {% endif %}
                  {{ key }}
                </a>
              </li>
            {% endfor %}

            {# Add an ellipsis if there are further next pages. #}
            {% if ellipses.next %}
              <li class=\"page-item\">
                <span class=\"page-link dots\">...</span>
              </li>
            {% endif %}

            {# Print last item if we are not on the last page and it's not already included in the pages list. #}
            {% if items.last is not empty %}
              {% set pageNumber = items.last.href|split('=')|last + 1 %}
              {% if pageNumber not in items.pages|keys %}
                {% if not items.last.is_active %}
                  <li class=\"page-item\">
                    <a href=\"{{ items.last.href }}\" title=\"Go to page {{ pageNumber }}\">
                      <span class=\"visually-hidden\">Page</span>{{ pageNumber }}
                    </a>
                  </li>
                {% endif %}
              {% endif %}
            {% endif %}
          </ul>
        </nav>
      </div>
    </div>
  </nav>
{% endif %}

{# {% if items %}
  <!-- P A G I N A T I O N -->
  <nav aria-label=\"navigation\" aria-labelledby=\"{{ heading_id }}\">
    <ul class=\"pagination mb-0\" data-aos=\"fade-up\">
      {% for key, item in items.pages %}
        {% if key <= 5 %}
          <li class=\"page-item {{ current == key ? ' active' : '' }}\"><a class=\"page-link\" href=\"{{ item.href }}\">{{ key }}</a></li>
        {% elseif key == 6 %}
          <li class=\"page-item\"><span class=\"page-link dots\">...</span></li>
        {% elseif key == loop.last %}
          <li class=\"page-item {{ current == key ? ' active' : '' }}\"><a class=\"page-link\" href=\"{{ item.href }}\">{{ key }}</a></li>
        {% endif %}
      {% endfor %}
    </ul>
  </nav>
  <!-- END.P A G I N A T I O N -->
{% endif %} #}



", "themes/custom/atp/templates/system/pager.html.twig", "C:\\laragon\\www\\atp\\themes\\custom\\atp\\templates\\system\\pager.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 36, "set" => 44, "for" => 64];
        static $filters = ["escape" => 40, "last" => 44, "split" => 44, "keys" => 45];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'set', 'for'],
                ['escape', 'last', 'split', 'keys'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
