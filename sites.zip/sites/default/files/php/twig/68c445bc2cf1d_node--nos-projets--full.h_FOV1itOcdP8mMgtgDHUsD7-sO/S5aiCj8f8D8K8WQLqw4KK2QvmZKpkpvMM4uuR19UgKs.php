<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/atp/templates/node/node--nos-projets--full.html.twig */
class __TwigTemplate_475bc2631f70ef9905213ce2c6cd4b9f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 112
        yield "  <section class=\"banner_bread carriere Project_detail_page_banner\">
    <div id=\"slider--animate\">
      <!-- Slide 1 -->
      <div class=\"owl-slide\">
        <img src=\"";
        // line 116
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_image_detais", [], "any", false, false, true, 116), "entity", [], "any", false, false, true, 116), "uri", [], "any", false, false, true, 116), "value", [], "any", false, false, true, 116)), "html", null, true);
        yield "\" alt=\"Hospital Building\" class=\"img-fluid slide-bg\">
        <div class=\"slide-overlay\"></div>
        <div class=\"slide-content\">
          <h1 class=\"slide-title text-center\">";
        // line 119
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "title", [], "any", false, false, true, 119), "value", [], "any", false, false, true, 119), "html", null, true);
        yield "</h1>
          <br>
          <p class=\"mb-3 text-center cible___title\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\"
              viewBox=\"0 0 24 24\" fill=\"none\">
              <path
                d=\"M17.15 9.6L10 16.75L6.8 13.55L7.5 12.84L10 15.34L16.44 8.89L17.15 9.6ZM11.5 3C16.75 3 21 7.25 21 12.5C21 17.75 16.75 22 11.5 22C6.25 22 2 17.75 2 12.5C2 7.25 6.25 3 11.5 3ZM11.5 4C6.81 4 3 7.81 3 12.5C3 17.19 6.81 21 11.5 21C16.19 21 20 17.19 20 12.5C20 7.81 16.19 4 11.5 4Z\"
                fill=\"white\" />
            </svg> ";
        // line 126
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "field_annee_projet", [], "any", false, false, true, 126), "value", [], "any", false, false, true, 126), "html", null, true);
        yield " <span> / </span> ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "field_pays_et_villes", [], "any", false, false, true, 126), "value", [], "any", false, false, true, 126), "html", null, true);
        yield "</p>

        </div>
      </div>

    </div>
  </section>
 ";
        // line 133
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "body", [], "any", false, false, true, 133), "html", null, true);
        yield "
  ";
        // line 134
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "field_galerie_de_projets", [], "any", false, false, true, 134), "html", null, true);
        yield "
  \t";
        // line 135
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, views_embed_view("projets", "block_1"), "html", null, true);
        yield "
 ";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["node", "content"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/atp/templates/node/node--nos-projets--full.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  86 => 135,  82 => 134,  78 => 133,  66 => 126,  56 => 119,  50 => 116,  44 => 112,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Olivero's theme implementation to display a node.
 *
 * Available variables:
 * - node: The node entity with limited access to object properties and methods.
 *   Only method names starting with \"get\", \"has\", or \"is\" and a few common
 *   methods such as \"id\", \"label\", and \"bundle\" are available. For example:
 *   - node.getCreatedTime() will return the node creation timestamp.
 *   - node.hasField('field_example') returns TRUE if the node bundle includes
 *     field_example. (This does not indicate the presence of a value in this
 *     field.)
 *   - node.isPublished() will return whether the node is published or not.
 *   Calling other methods, such as node.delete(), will result in an exception.
 *   See \\Drupal\\node\\Entity\\Node for a full list of public properties and
 *   methods for the node object.
 * - label: (optional) The title of the node.
 * - content: All node items. Use {{ content }} to print them all,
 *   or print a subset such as {{ content.field_example }}. Use
 *   {{ content|without('field_example') }} to temporarily suppress the printing
 *   of a given child element.
 * - author_picture: The node author user entity, rendered using the \"compact\"
 *   view mode.
 * - metadata: Metadata for this node.
 * - date: (optional) Themed creation date field.
 * - author_name: (optional) Themed author name field.
 * - url: Direct URL of the current node.
 * - display_submitted: Whether submission information should be displayed.
 * - attributes: HTML attributes for the containing element.
 *   The attributes.class element may contain one or more of the following
 *   classes:
 *   - node: The current template type (also known as a \"theming hook\").
 *   - node--type-[type]: The current node type. For example, if the node is an
 *     \"Article\" it would result in \"node--type-article\". Note that the machine
 *     name will often be in a short form of the human readable label.
 *   - node--view-mode-[view_mode]: The View Mode of the node; for example, a
 *     teaser would result in: \"node--view-mode-teaser\", and
 *     full: \"node--view-mode-full\".
 *   The following are controlled through the node publishing options.
 *   - node--promoted: Appears on nodes promoted to the front page.
 *   - node--sticky: Appears on nodes ordered above other non-sticky nodes in
 *     teaser listings.
 *   - node--unpublished: Appears on unpublished nodes visible only to site
 *     admins.
 * - title_attributes: Same as attributes, except applied to the main title
 *   tag that appears in the template.
 * - content_attributes: Same as attributes, except applied to the main
 *   content tag that appears in the template.
 * - author_attributes: Same as attributes, except applied to the author of
 *   the node tag that appears in the template.
 * - title_prefix: Additional output populated by modules, intended to be
 *   displayed in front of the main title tag that appears in the template.
 * - title_suffix: Additional output populated by modules, intended to be
 *   displayed after the main title tag that appears in the template.
 * - view_mode: View mode; for example, \"teaser\" or \"full\".
 * - teaser: Flag for the teaser state. Will be true if view_mode is 'teaser'.
 * - page: Flag for the full page state. Will be true if view_mode is 'full'.
 * - readmore: Flag for more state. Will be true if the teaser content of the
 *   node cannot hold the main body content.
 * - logged_in: Flag for authenticated user status. Will be true when the
 *   current user is a logged-in member.
 * - is_admin: Flag for admin user status. Will be true when the current user
 *   is an administrator.
 *
 * @see template_preprocess_node()
 */
#}
{# <div class=\"container container-md mb-5\">
\t<div class=\"card\" data-aos=\"fade-up\">
\t\t<div class=\"card-body details-cms\">
\t\t\t{% if node.field_photo_couverture is not empty %}
\t\t\t\t<img src=\"{{ file_url(node.field_photo_couverture.entity.uri.value|image_style('details_actualite')) }}\" class=\"card-img-top rounded-15 mb-5 w-auto\" loading=\"lazy\" alt=\"logo detail actualites\">
\t\t\t{% endif %}
\t\t\t<p class=\"card-text mb-4\">
\t\t\t\t<small>{{ node.field_date.date|date('d/m/Y') }}</small>
\t\t\t</p>
\t\t\t<p>
\t\t\t\t{% if node.body is not empty %}
\t\t\t\t\t{{ content.body }}
\t\t\t\t{% endif %}
\t\t\t</p>

\t\t\t<!-- Share buttons -->
\t\t\t<div class=\"share-links  a2a_kit a2a_kit_size_32 a2a_default_style\">
\t\t\t\t<div class=\"h4\">{{ (\"Partager cette actualité\")|t }}</div>

\t\t\t\t<!-- Links -->
\t\t\t\t<a href=\"#\" title=\"{{ (\"Partagez sur Facebook\")|t }}\" class=\"text-info btn btn-outline-info a2a_button_facebook\" data-toggle=\"tooltip\" data-placement=\"top\">
\t\t\t\t\t<i class=\"fab fa-facebook-f\"></i>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" title=\"{{ (\"Partagez sur linkedin\")|t }}\" class=\"text-info btn btn-outline-info a2a_button_linkedin\" data-toggle=\"tooltip\" data-placement=\"top\">
\t\t\t\t\t<i class=\"fa-brands fa-linkedin\"></i>
\t\t\t\t</a>

\t\t\t\t<a href=\"#\" title=\"{{ (\"Partagez sur x\")|t }}\" class=\"text-info btn btn-outline-info a2a_button_x\" data-toggle=\"tooltip\" data-placement=\"top\">
\t\t\t\t\t<svg class=\"svg-inline--x\" xmlns=\"http://www.w3.org/2000/svg\" width=\"20.056\" height=\"18.772\" viewbox=\"0 0 20.056 18.772\">
\t\t\t\t\t\t<path id=\"path1009\" d=\"M281.549,167.31l7.744,10.354-7.792,8.418h1.754l6.822-7.37,5.512,7.37h5.968l-8.179-10.936,7.253-7.836h-1.754l-6.283,6.788-5.077-6.788Zm2.579,1.292h2.742l12.107,16.188h-2.742Z\" transform=\"translate(-281.5 -167.31)\" fill=\"#1fb7be\"/>
\t\t\t\t\t</svg>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" title=\"{{ (\"Partagez sur whatsapp\")|t }}\" class=\"text-info btn btn-outline-info a2a_button_whatsapp\" data-toggle=\"tooltip\" data-placement=\"top\">
\t\t\t\t\t<i class=\"fa-brands fa-whatsapp\"></i>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" title=\"{{ (\"click to copy\")|t }}\" class=\"text-info btn btn-outline-info clipboard\" data-toggle=\"tooltip\" data-placement=\"top\">
\t\t\t\t\t<i class=\"fas fa-link\"></i>
\t\t\t\t</a>
\t\t\t</div>
\t\t</div>
\t</div>
\t<!-- END.Card Detail -->
</div> #}
  <section class=\"banner_bread carriere Project_detail_page_banner\">
    <div id=\"slider--animate\">
      <!-- Slide 1 -->
      <div class=\"owl-slide\">
        <img src=\"{{ file_url(node.field_banner_image_detais.entity.uri.value) }}\" alt=\"Hospital Building\" class=\"img-fluid slide-bg\">
        <div class=\"slide-overlay\"></div>
        <div class=\"slide-content\">
          <h1 class=\"slide-title text-center\">{{ node.title.value }}</h1>
          <br>
          <p class=\"mb-3 text-center cible___title\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\"
              viewBox=\"0 0 24 24\" fill=\"none\">
              <path
                d=\"M17.15 9.6L10 16.75L6.8 13.55L7.5 12.84L10 15.34L16.44 8.89L17.15 9.6ZM11.5 3C16.75 3 21 7.25 21 12.5C21 17.75 16.75 22 11.5 22C6.25 22 2 17.75 2 12.5C2 7.25 6.25 3 11.5 3ZM11.5 4C6.81 4 3 7.81 3 12.5C3 17.19 6.81 21 11.5 21C16.19 21 20 17.19 20 12.5C20 7.81 16.19 4 11.5 4Z\"
                fill=\"white\" />
            </svg> {{ node.field_annee_projet.value }} <span> / </span> {{ node.field_pays_et_villes.value }}</p>

        </div>
      </div>

    </div>
  </section>
 {{ content.body }}
  {{ content.field_galerie_de_projets }}
  \t{{ drupal_view('projets','block_1') }}
 {# <section class=\"section--4\">
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-lg-12\">
          <div class=\"title--sc\">
            <h2 class=\"section-title\">Autres projets</h2>


          </div>

        </div>
      </div>



      <div class=\"row\">
        <div class=\"col-md-6 col-lg-4 mb-4\">
          <div class=\"project-card card\">
            <a href=\"#\">
              <img src=\"/themes/custom/atp/atp/assets/images/new1.png\" class=\"project-img card-img-top\" alt=\"Projet architectural moderne\">
              <div class=\"card-body\">
                <div class=\"project-category\">Glass Tower Complex</div>
                <h3 class=\"project-title\">Tour Lumina</h3>
                <p class=\"project-description\">Une tour de 40 étages alliant durabilité et innovation technologique au
                  cœur du quartier d'affaires.</p>
                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
                    viewBox=\"0 0 20 20\" fill=\"none\">
                    <path
                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
                      fill=\"white\" />
                  </svg>Terminé en 2021 </div>
              </div>
            </a>
          </div>
        </div>

        <div class=\"col-md-6 col-lg-4 mb-4\">
          <div class=\"project-card card\">
            <a href=\"#\">
              <img src=\"/themes/custom/atp/atp/assets/images/new2.png\" class=\"project-img card-img-top\" alt=\"Projet résidentiel\">
              <div class=\"card-body\">
                <div class=\"project-category\">Anfa prime hospital</div>
                <h3 class=\"project-title\">Résidence Horizon</h3>
                <p class=\"project-description\">Un complexe résidentiel de 80 unités intégrant des espaces verts et des
                  équipements communautaires.</p>
                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
                    viewBox=\"0 0 20 20\" fill=\"none\">
                    <path
                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
                      fill=\"white\" />
                  </svg>Terminé en 2021 </div>
              </div>
            </a>
          </div>
        </div>

        <div class=\"col-md-6 col-lg-4 mb-4\">
          <div class=\"project-card card\">
            <a href=\"#\">
              <img src=\"/themes/custom/atp/atp/assets/images/new3.png\" class=\"project-img card-img-top\" alt=\"Projet urbain\">
              <div class=\"card-body\">
                <div class=\"project-category\">MH CMNMC</div>
                <h3 class=\"project-title\">Parc Central</h3>
                <p class=\"project-description\">Réaménagement de 12 hectares en espace vert public avec installations
                  sportives et culturelles.</p>
                <div class=\"see-all-link\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
                    viewBox=\"0 0 20 20\" fill=\"none\">
                    <path
                      d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
                      fill=\"white\" />
                  </svg>Terminé en 2021 </div>
              </div>
            </a>
          </div>
        </div>
      </div>
      <!--
      <div class=\"text-center\">
        <a href=\"#\" class=\"btn btn-discover\">
          Découvrir ATP <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\">
            <rect width=\"32\" height=\"32\" rx=\"16\" fill=\"white\" />
            <g clip-path=\"url(#clip0_6010_3350)\">
              <path fill-rule=\"evenodd\" clip-rule=\"evenodd\"
                d=\"M16.4345 7.01562C16.4345 8.11199 16.6302 9.19763 17.0104 10.2105C17.3906 11.2235 17.9479 12.1438 18.6504 12.9191C19.3529 13.6943 20.1869 14.3093 21.1048 14.7288C22.0226 15.1484 23.0065 15.3643 24 15.3643V15.3997V16.5997V16.6351C23.0065 16.6351 22.0226 16.8511 21.1048 17.2706C20.1869 17.6902 19.3529 18.3051 18.6504 19.0804C17.9479 19.8556 17.3906 20.7761 17.0104 21.789C16.6302 22.8018 16.4345 23.8875 16.4345 24.9838H15.2077C15.2077 20.455 17.9943 17.4498 21.7469 16.5997H8L8 15.3997H21.747C17.9943 14.5497 15.2077 11.5444 15.2077 7.01562H16.4345Z\"
                fill=\"black\" />
            </g>
            <defs>
              <clipPath id=\"clip0_6010_3350\">
                <rect width=\"16\" height=\"16\" fill=\"white\" transform=\"translate(8 8)\" />
              </clipPath>
            </defs>
          </svg></i>
        </a>
      </div> -->
    </div>
</section> #}
", "themes/custom/atp/templates/node/node--nos-projets--full.html.twig", "C:\\laragon\\www\\atp\\themes\\custom\\atp\\templates\\node\\node--nos-projets--full.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["escape" => 116];
        static $functions = ["file_url" => 116, "drupal_view" => 135];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape'],
                ['file_url', 'drupal_view'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
