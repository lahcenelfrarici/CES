<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/atp/templates/navigation/menu--main.html.twig */
class __TwigTemplate_e7f10aaa1e538557546682b814dae32b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 23
        $macros["menus"] = $this->macros["menus"] = $this;
        // line 24
        yield " ";
        // line 40
        yield "<ul class=\"navbar-nav ms-auto\">
  ";
        // line 41
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($macros["menus"]->getTemplateForMacro("macro_menu_links", $context, 41, $this->getSourceContext())->macro_menu_links(...[($context["items"] ?? null), ($context["attributes"] ?? null), 0]));
        yield "
</ul>

";
        // line 75
        yield "
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["_self", "items", "attributes", "loop", "menu_level"]);        yield from [];
    }

    // line 44
    public function macro_menu_links($items = null, $attributes = null, $menu_level = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "items" => $items,
            "attributes" => $attributes,
            "menu_level" => $menu_level,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 45
            yield "  ";
            $macros["menus"] = $this;
            // line 46
            yield "  ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 47
                yield "    ";
                $context["has_children"] =  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 47));
                // line 48
                yield "    <li class=\"nav-item";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["has_children"] ?? null)) ? (" dropdown") : ("")));
                yield "\">
      <a
        href=\"";
                // line 50
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, true, 50), "html", null, true);
                yield "\"
        class=\"nav-link";
                // line 51
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["has_children"] ?? null)) ? (" dropdown-toggle") : ("")));
                yield "\"
        ";
                // line 52
                if (($context["has_children"] ?? null)) {
                    // line 53
                    yield "          id=\"navbarScrollingDropdown-";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, true, 53), "html", null, true);
                    yield "\"
          role=\"button\"
          data-bs-toggle=\"dropdown\"
          aria-expanded=\"false\"
        ";
                }
                // line 58
                yield "      >
        ";
                // line 59
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 59), "html", null, true);
                yield "
        ";
                // line 60
                if (($context["has_children"] ?? null)) {
                    // line 61
                    yield "          <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"11\" height=\"8\" viewBox=\"0 0 11 8\" fill=\"none\">
            <path d=\"M1.2832 2L5.4082 6L9.5332 2\" stroke=\"#000849\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>
          </svg>
        ";
                }
                // line 65
                yield "      </a>

      ";
                // line 67
                if (($context["has_children"] ?? null)) {
                    // line 68
                    yield "        <ul class=\"dropdown-menu\" aria-labelledby=\"navbarScrollingDropdown-";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, true, 68), "html", null, true);
                    yield "\">
          ";
                    // line 69
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($macros["menus"]->getTemplateForMacro("macro_menu_links", $context, 69, $this->getSourceContext())->macro_menu_links(...[CoreExtension::getAttribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 69), ($context["attributes"] ?? null), (($context["menu_level"] ?? null) + 1)]));
                    yield "
        </ul>
      ";
                }
                // line 72
                yield "    </li>
  ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/atp/templates/navigation/menu--main.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  159 => 72,  153 => 69,  148 => 68,  146 => 67,  142 => 65,  136 => 61,  134 => 60,  130 => 59,  127 => 58,  118 => 53,  116 => 52,  112 => 51,  108 => 50,  102 => 48,  99 => 47,  81 => 46,  78 => 45,  64 => 44,  57 => 75,  51 => 41,  48 => 40,  46 => 24,  44 => 23,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Default theme implementation to display a menu.
 *
 * Available variables:
 * - menu_name: The machine name of the menu.
 * - items: A nested list of menu items. Each menu item contains:
 *   - attributes: HTML attributes for the menu item.
 *   - below: The menu item child items.
 *   - title: The menu link title.
 *   - url: The menu link URL, instance of \\Drupal\\Core\\Url
 *   - localized_options: Menu link localized options.
 *   - is_expanded: TRUE if the link has visible children within the current
 *     menu tree.
 *   - is_collapsed: TRUE if the link has children within the current menu tree
 *     that are not currently visible.
 *   - in_active_trail: TRUE if the link is in the active trail.
 *
 * @ingroup themeable
 */
#}
{% import _self as menus %}
 {# <ul class=\"navbar-nav ms-auto\">
\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"/index.html\">Accueil</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"/Our_hestory.html\">Agence</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"/Nos_projets.html\">Projets</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"/carriere.html\">Carrières</a>
\t\t\t\t\t</li>

\t\t\t\t</ul> #}
{# Render the menu with Bootstrap wrapper and custom classes #}
<ul class=\"navbar-nav ms-auto\">
  {{ menus.menu_links(items, attributes, 0) }}
</ul>

{% macro menu_links(items, attributes, menu_level) %}
  {% import _self as menus %}
  {% for item in items %}
    {% set has_children = item.below is not empty %}
    <li class=\"nav-item{{ has_children ? ' dropdown' : '' }}\">
      <a
        href=\"{{ item.url }}\"
        class=\"nav-link{{ has_children ? ' dropdown-toggle' : '' }}\"
        {% if has_children %}
          id=\"navbarScrollingDropdown-{{ loop.index }}\"
          role=\"button\"
          data-bs-toggle=\"dropdown\"
          aria-expanded=\"false\"
        {% endif %}
      >
        {{ item.title }}
        {% if has_children %}
          <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"11\" height=\"8\" viewBox=\"0 0 11 8\" fill=\"none\">
            <path d=\"M1.2832 2L5.4082 6L9.5332 2\" stroke=\"#000849\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>
          </svg>
        {% endif %}
      </a>

      {% if has_children %}
        <ul class=\"dropdown-menu\" aria-labelledby=\"navbarScrollingDropdown-{{ loop.index }}\">
          {{ menus.menu_links(item.below, attributes, menu_level + 1) }}
        </ul>
      {% endif %}
    </li>
  {% endfor %}
{% endmacro %}

", "themes/custom/atp/templates/navigation/menu--main.html.twig", "C:\\laragon\\www\\atp\\themes\\custom\\atp\\templates\\navigation\\menu--main.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["import" => 23, "macro" => 44, "for" => 46, "set" => 47, "if" => 52];
        static $filters = ["escape" => 50];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['import', 'macro', 'for', 'set', 'if'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
