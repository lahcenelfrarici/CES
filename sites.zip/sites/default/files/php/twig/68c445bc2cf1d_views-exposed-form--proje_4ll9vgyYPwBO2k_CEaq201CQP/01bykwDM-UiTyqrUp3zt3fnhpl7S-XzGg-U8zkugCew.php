<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/atp/templates/form/views-exposed-form--projets-page-1.html.twig */
class __TwigTemplate_a24eb5fa9c93be6aff40b19d3d06084b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 14
        yield "
";
        // line 30
        yield "
";
        // line 32
        yield "
<form ";
        // line 33
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["attributes"] ?? null), "html", null, true);
        yield ">
<div class=\"col-md-4\">
\t\t\t\t\t<div class=\"filter-option\">
           ";
        // line 36
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, true, 36), "html", null, true);
        yield "
\t\t\t\t\t\t";
        // line 38
        yield "\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 select__list\" id=\"select__list\">
\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t<div class=\"filter-label\">Lieu</div>
\t\t\t\t\t";
        // line 43
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "field_lieu_value", [], "any", false, false, true, 43), "html", null, true);
        yield "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 select__list\">
\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t<div class=\"filter-label\">Type</div>
\t\t\t\t\t\t";
        // line 49
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "field_type_value", [], "any", false, false, true, 49), "html", null, true);
        yield "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 select__list\">
\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t<div class=\"filter-label\">Etat</div>
\t\t\t\t\t";
        // line 55
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "field_etat_value", [], "any", false, false, true, 55), "html", null, true);
        yield "
\t\t\t\t\t</div>
\t\t\t\t</div>
        <div class=\"btn__sbmt col-md-2\">
          ";
        // line 59
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "actions", [], "any", false, false, true, 59), "submit", [], "any", false, false, true, 59), "html", null, true);
        yield "
        </div>
</form>

";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["attributes", "form"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/atp/templates/form/views-exposed-form--projets-page-1.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  95 => 59,  88 => 55,  79 => 49,  70 => 43,  63 => 38,  59 => 36,  53 => 33,  50 => 32,  47 => 30,  44 => 14,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Default theme implementation of a views exposed form.
 *
 * Available variables:
 * - form: A render element representing the form.
 *
 * @see template_preprocess_views_exposed_form()
 *
 * @ingroup themeable
 */
#}

{# <form {{ attributes }}>
  <div class=\"row mb-4\">
    <div class=\"col-12 col-md-3 mb-3\">
     {{ form.sort_bef_combine }}
    </div>
    <div class=\"col-12 col-md-3 mb-3\">
      {{ form.year }}
    </div>

    <!-- Action search -->
    <div class=\"col-auto mb-3\">
      {{ form.actions }}
    </div>
  </div>
</form> #}

{# views-exposed-form--news-page-1.html.twig #}

<form {{ attributes }}>
<div class=\"col-md-4\">
\t\t\t\t\t<div class=\"filter-option\">
           {{ form.title }}
\t\t\t\t\t\t{# <input type=\"text\" class=\"form-control\" placeholder=\"Rechercher des projets par nom ou description\"> #}
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 select__list\" id=\"select__list\">
\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t<div class=\"filter-label\">Lieu</div>
\t\t\t\t\t{{ form.field_lieu_value }}
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 select__list\">
\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t<div class=\"filter-label\">Type</div>
\t\t\t\t\t\t{{ form.field_type_value }}
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 select__list\">
\t\t\t\t\t<div class=\"filter-option\">
\t\t\t\t\t\t<div class=\"filter-label\">Etat</div>
\t\t\t\t\t{{ form.field_etat_value }}
\t\t\t\t\t</div>
\t\t\t\t</div>
        <div class=\"btn__sbmt col-md-2\">
          {{ form.actions.submit }}
        </div>
</form>

", "themes/custom/atp/templates/form/views-exposed-form--projets-page-1.html.twig", "C:\\laragon\\www\\atp\\themes\\custom\\atp\\templates\\form\\views-exposed-form--projets-page-1.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["escape" => 33];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
