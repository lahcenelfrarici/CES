<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/atp/templates/view/projets/views-view-fields--projets--page-1.html.twig */
class __TwigTemplate_d2dfd6db3ca1d7762a7d1ef22c1e014c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 35
        yield "
";
        // line 75
        yield " <div class=\"col-md-6 col-lg-4 mb-4\">
          <div class=\"project-card card\">
            <a href=\"";
        // line 77
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getPath("entity.node.canonical", ["node" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["row"] ?? null), "_entity", [], "any", false, false, true, 77), "nid", [], "any", false, false, true, 77), "value", [], "any", false, false, true, 77)]), "html", null, true);
        yield "\">
              <img src=\"";
        // line 78
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["row"] ?? null), "_entity", [], "any", false, false, true, 78), "field_image", [], "any", false, false, true, 78), "entity", [], "any", false, false, true, 78), "fileuri", [], "any", false, false, true, 78)), "html", null, true);
        yield "\" class=\"project-img card-img-top\" alt=\"Projet architectural moderne\">
              <div class=\"card-body\">
                <div class=\"project-category\">";
        // line 80
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "title", [], "any", false, false, true, 80), "content", [], "any", false, false, true, 80), "html", null, true);
        yield "</div>
                <h3 class=\"project-title\">";
        // line 81
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "field_pays_et_villes", [], "any", false, false, true, 81), "content", [], "any", false, false, true, 81), "html", null, true);
        yield "</h3>

                <div class=\"see-all-link\">
                  <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
                      viewBox=\"0 0 20 20\" fill=\"none\">
                      <path
                        d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
                        fill=\"white\" />
                  </svg>
                  ";
        // line 90
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "field_annee_projet", [], "any", false, false, true, 90), "content", [], "any", false, false, true, 90), "html", null, true);
        yield "
                </div>
              </div>
            </a>
          </div>
  </div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["row", "fields"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/atp/templates/view/projets/views-view-fields--projets--page-1.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  76 => 90,  64 => 81,  60 => 80,  55 => 78,  51 => 77,  47 => 75,  44 => 35,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
/**
 * @file
 * Default theme implementation for main view template.
 *
 * Available variables:
 * - attributes: Remaining HTML attributes for the element.
 * - css_name: A CSS-safe version of the view name.
 * - css_class: The user-specified classes names, if any.
 * - header: The optional header.
 * - footer: The optional footer.
 * - rows: The results of the view query, if any.
 * - empty: The content to display if there are no rows.
 * - pager: The optional pager next/prev links to display.
 * - exposed: Exposed widget form/info to display.
 * - feed_icons: Optional feed icons to display.
 * - more: An optional link to the next page of results.
 * - title: Title of the view, only used when displaying in the admin preview.
 * - title_prefix: Additional output populated by modules, intended to be
 *   displayed in front of the view title.
 * - title_suffix: Additional output populated by modules, intended to be
 *   displayed after the view title.
 * - attachment_before: An optional attachment view to be displayed before the
 *   view content.
 * - attachment_after: An optional attachment view to be displayed after the
 *   view content.
 * - dom_id: Unique id for every view being printed to give unique class for
 *   JavaScript.
 *
 * @see template_preprocess_views_view()
 *
 * @ingroup themeable
 */
#}

{# <div class=\"col-md-4\">
\t<div class=\"card\">
\t\t<img src=\"{{ file_url(row._entity.field_image_news.entity.fileuri) }}\" class=\"card-img-top\" alt=\"Image\">
\t\t<div class=\"card-body\">
\t\t\t<div class=\"article-date\">
\t\t\t\t<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"26\" height=\"27\" viewbox=\"0 0 26 27\" fill=\"none\">
\t\t\t\t\t<g clip-path=\"url(#clip0_4698_14065)\">
\t\t\t\t\t\t<path d=\"M7.3749 0.71875C7.61625 0.71875 7.84771 0.814625 8.01837 0.985283C8.18902 1.15594 8.2849 1.3874 8.2849 1.62875V3.33045H18.057V1.64045C18.057 1.3991 18.1529 1.16764 18.3235 0.996983C18.4942 0.826325 18.7257 0.73045 18.967 0.73045C19.2083 0.73045 19.4398 0.826325 19.6105 0.996983C19.7811 1.16764 19.877 1.3991 19.877 1.64045V3.33045H23.4C24.0893 3.33045 24.7505 3.6042 25.238 4.09151C25.7256 4.57883 25.9997 5.23981 26 5.92915V24.12C25.9997 24.8094 25.7256 25.4704 25.238 25.9577C24.7505 26.445 24.0893 26.7188 23.4 26.7188H2.6C1.91066 26.7188 1.24954 26.445 0.761982 25.9577C0.274425 25.4704 0.000344669 24.8094 0 24.12L0 5.92915C0.000344669 5.23981 0.274425 4.57883 0.761982 4.09151C1.24954 3.6042 1.91066 3.33045 2.6 3.33045H6.4649V1.62745C6.46524 1.38633 6.56127 1.1552 6.73189 0.984823C6.90251 0.814446 7.13378 0.71875 7.3749 0.71875ZM1.82 10.7833V24.12C1.82 24.2225 1.84018 24.3239 1.87937 24.4185C1.91857 24.5132 1.97603 24.5992 2.04846 24.6716C2.12089 24.744 2.20687 24.8015 2.30151 24.8407C2.39614 24.8799 2.49757 24.9 2.6 24.9H23.4C23.5024 24.9 23.6039 24.8799 23.6985 24.8407C23.7931 24.8015 23.8791 24.744 23.9515 24.6716C24.024 24.5992 24.0814 24.5132 24.1206 24.4185C24.1598 24.3239 24.18 24.2225 24.18 24.12V10.8015L1.82 10.7833ZM8.6671 19.7234V21.8892H6.5V19.7234H8.6671ZM14.0829 19.7234V21.8892H11.9171V19.7234H14.0829ZM19.5 19.7234V21.8892H17.3329V19.7234H19.5ZM8.6671 14.5533V16.7191H6.5V14.5533H8.6671ZM14.0829 14.5533V16.7191H11.9171V14.5533H14.0829ZM19.5 14.5533V16.7191H17.3329V14.5533H19.5ZM6.4649 5.14915H2.6C2.49757 5.14915 2.39614 5.16932 2.30151 5.20852C2.20687 5.24772 2.12089 5.30518 2.04846 5.37761C1.97603 5.45004 1.91857 5.53602 1.87937 5.63066C1.84018 5.72529 1.82 5.82672 1.82 5.92915V8.96465L24.18 8.98285V5.92915C24.18 5.82672 24.1598 5.72529 24.1206 5.63066C24.0814 5.53602 24.024 5.45004 23.9515 5.37761C23.8791 5.30518 23.7931 5.24772 23.6985 5.20852C23.6039 5.16932 23.5024 5.14915 23.4 5.14915H19.877V6.35685C19.877 6.5982 19.7811 6.82966 19.6105 7.00032C19.4398 7.17098 19.2083 7.26685 18.967 7.26685C18.7257 7.26685 18.4942 7.17098 18.3235 7.00032C18.1529 6.82966 18.057 6.5982 18.057 6.35685V5.14915H8.2849V6.34515C8.2849 6.5865 8.18902 6.81796 8.01837 6.98862C7.84771 7.15928 7.61625 7.25515 7.3749 7.25515C7.13355 7.25515 6.90209 7.15928 6.73143 6.98862C6.56077 6.81796 6.4649 6.5865 6.4649 6.34515V5.14915Z\" fill=\"#929292\"></path>
\t\t\t\t\t</g>
\t\t\t\t\t<defs>
\t\t\t\t\t\t<clipPath id=\"clip0_4698_14065\">
\t\t\t\t\t\t\t<rect width=\"26\" height=\"26\" fill=\"white\" transform=\"translate(0 0.71875)\"></rect>
\t\t\t\t\t\t</clipPath>
\t\t\t\t\t</defs>
\t\t\t\t</svg>
\t\t\t\t{{ fields.field_date.content}}</div>
\t\t\t<h5 class=\"card-title\">{{ fields.title.content }}</h5>
\t\t\t<div class=\"btn--pls\">
\t\t\t\t<a class=\"\" href=\"{{ path('entity.node.canonical', {'node':row._entity.nid.value}) }}\">
\t\t\t\t\t<span>{{'Read more'|t}}</span>
\t\t\t\t\t<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"48\" height=\"48\" viewbox=\"0 0 48 48\" fill=\"none\">
\t\t\t\t\t\t<g clip-path=\"url(#clip0_4948_4128)\">
\t\t\t\t\t\t\t<path d=\"M40.7279 22.5873C41.1028 22.9623 41.3135 23.4709 41.3135 24.0013C41.3135 24.5316 41.1028 25.0402 40.7279 25.4153L29.4139 36.7293C29.2294 36.9203 29.0087 37.0727 28.7647 37.1775C28.5207 37.2823 28.2583 37.3375 27.9927 37.3398C27.7271 37.3421 27.4638 37.2915 27.218 37.1909C26.9722 37.0903 26.7489 36.9418 26.5611 36.7541C26.3733 36.5663 26.2248 36.343 26.1243 36.0972C26.0237 35.8514 25.9731 35.588 25.9754 35.3225C25.9777 35.0569 26.0329 34.7945 26.1377 34.5505C26.2425 34.3065 26.3949 34.0858 26.5859 33.9013L34.4859 26.0013H7.9999C7.46947 26.0013 6.96076 25.7906 6.58569 25.4155C6.21062 25.0404 5.9999 24.5317 5.9999 24.0013C5.9999 23.4708 6.21062 22.9621 6.58569 22.5871C6.96076 22.212 7.46947 22.0013 7.9999 22.0013H34.4859L26.5859 14.1013C26.2216 13.7241 26.02 13.2189 26.0246 12.6945C26.0291 12.1701 26.2395 11.6684 26.6103 11.2976C26.9811 10.9268 27.4827 10.7165 28.0071 10.7119C28.5315 10.7074 29.0367 10.9089 29.4139 11.2733L40.7279 22.5873Z\" fill=\"url(#paint0_linear_4948_4128)\"></path>
\t\t\t\t\t\t</g>
\t\t\t\t\t\t<defs>
\t\t\t\t\t\t\t<linearGradient id=\"paint0_linear_4948_4128\" x1=\"23.6567\" y1=\"37.3398\" x2=\"25.6881\" y2=\"13.0491\" gradientunits=\"userSpaceOnUse\">
\t\t\t\t\t\t\t\t<stop stop-color=\"#009681\"></stop>
\t\t\t\t\t\t\t\t<stop offset=\"1\" stop-color=\"#007565\"></stop>
\t\t\t\t\t\t\t</linearGradient>
\t\t\t\t\t\t\t<clipPath id=\"clip0_4948_4128\">
\t\t\t\t\t\t\t\t<rect width=\"48\" height=\"48\" fill=\"white\" transform=\"matrix(0 -1 -1 0 48 48)\"></rect>
\t\t\t\t\t\t\t</clipPath>
\t\t\t\t\t\t</defs>
\t\t\t\t\t</svg>
\t\t\t\t</a>
\t\t\t</div>
\t\t</div>
\t</div>
</div> #}
 <div class=\"col-md-6 col-lg-4 mb-4\">
          <div class=\"project-card card\">
            <a href=\"{{ path('entity.node.canonical', {'node':row._entity.nid.value}) }}\">
              <img src=\"{{ file_url(row._entity.field_image.entity.fileuri) }}\" class=\"project-img card-img-top\" alt=\"Projet architectural moderne\">
              <div class=\"card-body\">
                <div class=\"project-category\">{{ fields.title.content }}</div>
                <h3 class=\"project-title\">{{ fields.field_pays_et_villes.content }}</h3>

                <div class=\"see-all-link\">
                  <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\"
                      viewBox=\"0 0 20 20\" fill=\"none\">
                      <path
                        d=\"M15.1891 7.21816L8.03906 14.3682L4.83906 11.1682L5.53906 10.4582L8.03906 12.9582L14.4791 6.50816L15.1891 7.21816ZM9.53906 0.618164C14.7891 0.618164 19.0391 4.86816 19.0391 10.1182C19.0391 15.3682 14.7891 19.6182 9.53906 19.6182C4.28906 19.6182 0.0390625 15.3682 0.0390625 10.1182C0.0390625 4.86816 4.28906 0.618164 9.53906 0.618164ZM9.53906 1.61816C4.84906 1.61816 1.03906 5.42816 1.03906 10.1182C1.03906 14.8082 4.84906 18.6182 9.53906 18.6182C14.2291 18.6182 18.0391 14.8082 18.0391 10.1182C18.0391 5.42816 14.2291 1.61816 9.53906 1.61816Z\"
                        fill=\"white\" />
                  </svg>
                  {{ fields.field_annee_projet.content }}
                </div>
              </div>
            </a>
          </div>
  </div>
", "themes/custom/atp/templates/view/projets/views-view-fields--projets--page-1.html.twig", "C:\\laragon\\www\\atp\\themes\\custom\\atp\\templates\\view\\projets\\views-view-fields--projets--page-1.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["escape" => 77];
        static $functions = ["path" => 77, "file_url" => 78];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape'],
                ['path', 'file_url'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
