<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/atp/templates/view/projets/views-view--projets--block-1.html.twig */
class __TwigTemplate_72cf874509439640d321482514958e34 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "

";
        // line 14
        yield "

  <section class=\"section--4\">
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-lg-12\">
          <div class=\"title--sc\">
            <h2 class=\"section-title\">";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Autres projets"));
        yield "</h2>


          </div>

        </div>
      </div>



      <div class=\"row\">
    ";
        // line 32
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["rows"] ?? null), "html", null, true);
        yield "
      </div>
      <!--
      <div class=\"text-center\">
        <a href=\"#\" class=\"btn btn-discover\">
          Découvrir ATP <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\">
            <rect width=\"32\" height=\"32\" rx=\"16\" fill=\"white\" />
            <g clip-path=\"url(#clip0_6010_3350)\">
              <path fill-rule=\"evenodd\" clip-rule=\"evenodd\"
                d=\"M16.4345 7.01562C16.4345 8.11199 16.6302 9.19763 17.0104 10.2105C17.3906 11.2235 17.9479 12.1438 18.6504 12.9191C19.3529 13.6943 20.1869 14.3093 21.1048 14.7288C22.0226 15.1484 23.0065 15.3643 24 15.3643V15.3997V16.5997V16.6351C23.0065 16.6351 22.0226 16.8511 21.1048 17.2706C20.1869 17.6902 19.3529 18.3051 18.6504 19.0804C17.9479 19.8556 17.3906 20.7761 17.0104 21.789C16.6302 22.8018 16.4345 23.8875 16.4345 24.9838H15.2077C15.2077 20.455 17.9943 17.4498 21.7469 16.5997H8L8 15.3997H21.747C17.9943 14.5497 15.2077 11.5444 15.2077 7.01562H16.4345Z\"
                fill=\"black\" />
            </g>
            <defs>
              <clipPath id=\"clip0_6010_3350\">
                <rect width=\"16\" height=\"16\" fill=\"white\" transform=\"translate(8 8)\" />
              </clipPath>
            </defs>
          </svg></i>
        </a>
      </div> -->
    </div>
  </section>

";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["rows"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/atp/templates/view/projets/views-view--projets--block-1.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  71 => 32,  57 => 21,  48 => 14,  44 => 11,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{# <div class=\"select-items\">


 {{ rows }}
</div>
 <div class=\"select-items\">
    {{ rows }}
</div>

{{ dump(content) }} #}


{# ********* #}


  <section class=\"section--4\">
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-lg-12\">
          <div class=\"title--sc\">
            <h2 class=\"section-title\">{{'Autres projets'|t}}</h2>


          </div>

        </div>
      </div>



      <div class=\"row\">
    {{ rows }}
      </div>
      <!--
      <div class=\"text-center\">
        <a href=\"#\" class=\"btn btn-discover\">
          Découvrir ATP <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\">
            <rect width=\"32\" height=\"32\" rx=\"16\" fill=\"white\" />
            <g clip-path=\"url(#clip0_6010_3350)\">
              <path fill-rule=\"evenodd\" clip-rule=\"evenodd\"
                d=\"M16.4345 7.01562C16.4345 8.11199 16.6302 9.19763 17.0104 10.2105C17.3906 11.2235 17.9479 12.1438 18.6504 12.9191C19.3529 13.6943 20.1869 14.3093 21.1048 14.7288C22.0226 15.1484 23.0065 15.3643 24 15.3643V15.3997V16.5997V16.6351C23.0065 16.6351 22.0226 16.8511 21.1048 17.2706C20.1869 17.6902 19.3529 18.3051 18.6504 19.0804C17.9479 19.8556 17.3906 20.7761 17.0104 21.789C16.6302 22.8018 16.4345 23.8875 16.4345 24.9838H15.2077C15.2077 20.455 17.9943 17.4498 21.7469 16.5997H8L8 15.3997H21.747C17.9943 14.5497 15.2077 11.5444 15.2077 7.01562H16.4345Z\"
                fill=\"black\" />
            </g>
            <defs>
              <clipPath id=\"clip0_6010_3350\">
                <rect width=\"16\" height=\"16\" fill=\"white\" transform=\"translate(8 8)\" />
              </clipPath>
            </defs>
          </svg></i>
        </a>
      </div> -->
    </div>
  </section>

", "themes/custom/atp/templates/view/projets/views-view--projets--block-1.html.twig", "C:\\laragon\\www\\atp\\themes\\custom\\atp\\templates\\view\\projets\\views-view--projets--block-1.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["t" => 21, "escape" => 32];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['t', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
