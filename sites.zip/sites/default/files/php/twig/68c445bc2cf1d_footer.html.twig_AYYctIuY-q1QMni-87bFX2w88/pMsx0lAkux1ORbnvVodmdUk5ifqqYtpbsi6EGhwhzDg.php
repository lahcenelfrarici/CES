<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @atp/partials/footer.html.twig */
class __TwigTemplate_c490d1e7b73131b74a397ee18344bc69 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 76
        yield "<footer class=\"footer---btm bg-dark-red text-white pt-5 pb-3\">
\t<div class=\"container\">
\t\t<div
\t\t\tclass=\"row\">
\t\t\t<!-- Logo and slogan -->
\t\t\t<div class=\"col-md-3 mb-4\">
\t\t\t\t<a class=\"navbar-brand\" href=\"";
        // line 82
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("<front>"));
        yield "\">
\t\t\t\t\t<img class=\"two--sc--img mb-3\" src=\"/themes/custom/atp/atp/assets/images/logo.png\"></a>


\t\t\t\t<p>";
        // line 86
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Créer l'excellence architecturale à travers le Maroc et au-delà"));
        yield ".</p>
\t\t\t\t";
        // line 88
        yield "\t\t\t</div>

\t\t\t<!-- Quick links -->
\t\t\t<div class=\"col-md-3 mb-4\">
\t\t\t\t<h6 class=\"mb-3\">";
        // line 92
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Liens rapides"));
        yield "</h6>
\t\t\t\t";
        // line 99
        yield "\t\t\t\t";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_top_2", [], "any", false, false, true, 99)) {
            // line 100
            yield "\t\t\t\t\t";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_top_2", [], "any", false, false, true, 100), "html", null, true);
            yield "
\t\t\t\t";
        }
        // line 102
        yield "\t\t\t</div>

\t\t\t<!-- Contact information -->
\t\t\t<div
\t\t\t\tclass=\"col-md-3 mb-4 localed-icon\">
\t\t\t\t";
        // line 111
        yield "\t\t\t\t";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Drupal\twig_tweak\TwigTweakExtension::drupalEntity("block", "atp_footer3"), "html", null, true);
        yield "
\t\t\t</div>

\t\t\t<!-- Social links -->
\t\t\t<div class=\"col-md-3 mb-4\">
\t\t\t\t<h6 class=\"mb-3\">";
        // line 116
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Suivez-nous"));
        yield "</h6>
\t\t\t\t<a href=\"#\" class=\"footer-social\">
\t\t\t\t\t<i class=\"fa-brands fa-linkedin\"></i>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"footer-social\">
\t\t\t\t\t<i class=\"fa-brands fa-instagram\"></i>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"footer-social\">
\t\t\t\t\t<i class=\"fa-brands fa-facebook\"></i>
\t\t\t\t</a>
\t\t\t\t";
        // line 127
        yield "\t\t\t</div>
\t\t</div>

\t\t<hr class=\"border-light\">

\t\t<div class=\"text-center\">
\t\t\t<small>";
        // line 133
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("© 2025 Agence ATP. All rights reserved"));
        yield ".</small>
\t\t</div>
\t</div>
</footer>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@atp/partials/footer.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  119 => 133,  111 => 127,  98 => 116,  89 => 111,  82 => 102,  76 => 100,  73 => 99,  69 => 92,  63 => 88,  59 => 86,  52 => 82,  44 => 76,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
<section class=\"contact---us\" id=\"contact---us\">
\t<div
\t\tclass=\"contact-container\">
\t\t<!-- Left Form Section -->
\t\t<div class=\"contact-form\">
\t\t\t<h3>{{'I am interested in getting in touch with Casablanca Finance City'|t}}</h3>

\t\t\t<div class=\"web__form_dr\">
\t\t\t\t{{ drupal_entity('block','cfc_webform') }}
\t\t\t</div>
\t\t</div>

\t\t<!-- Right Image Section -->
\t\t<div class=\"contact-image\">
\t\t\t<img src=\"/themes/custom/cfc/CFC/assets/images/contatc-img.png\" alt=\"Office\"/>
\t\t</div>
\t</div>
</section>
<section class=\"section---filter-block\">
\t{{ drupal_view('news','block_1') }}
</section>


<footer class=\"bg-dark text-light py-5\">
\t<div class=\"container\">
\t\t<div
\t\t\tclass=\"row\">
\t\t\t<!-- Copyright -->
\t\t\t<div class=\"text-center mb-4\">
\t\t\t\t<p class=\"mb-0\">
\t\t\t\t\t{{ drupal_entity('block','cfc_copyright') }}</p>
\t\t\t</div>
\t\t\t<!-- Logo and Social Links -->
\t\t\t<div class=\"col-md-4 \">
\t\t\t\t{{ drupal_entity('block','cfc_logofooter') }}

\t\t\t\t{{ drupal_entity('block','cfc_socialmedia') }}


\t\t\t</div>

\t\t\t<!-- Stay Updated -->
\t\t\t<div class=\"col-md-4\">
\t\t\t\t<h5>{{ 'Stay Updated'|t }}</h5>
\t\t\t\t{{ drupal_entity('block','cfc_stayupdated') }}
\t\t\t\t<form class=\"d-flex mt-3\">
\t\t\t\t\t<input type=\"email\" class=\"form-control rounded-pill\" placeholder=\"Email...\" required=\"\">
\t\t\t\t\t<button type=\"submit\" class=\"form--news\">{{'Subscribe'|t}}
\t\t\t\t\t\t<i class=\"fas fa-arrow-right ms-2\"></i>
\t\t\t\t\t</button>
\t\t\t\t</form>
\t\t\t</div>

\t\t\t<!-- Quick Links -->
\t\t\t<div class=\"col-md-4\">

\t\t\t\t{{ drupal_entity('block','cfc_quicklinks') }}
\t\t\t</div>
\t\t</div>


\t</div>
\t<!-- Google tag (gtag.js) -->
\t<script async src=\"https://www.googletagmanager.com/gtag/js?id=G-9WWD1TRBQN\"></script>
\t<script>
\t\twindow.dataLayer = window.dataLayer || [];
function gtag() {
dataLayer.push(arguments);
}
gtag('js', new Date());

gtag('config', 'G-9WWD1TRBQN');
\t</script>
</footer> #}
<footer class=\"footer---btm bg-dark-red text-white pt-5 pb-3\">
\t<div class=\"container\">
\t\t<div
\t\t\tclass=\"row\">
\t\t\t<!-- Logo and slogan -->
\t\t\t<div class=\"col-md-3 mb-4\">
\t\t\t\t<a class=\"navbar-brand\" href=\"{{ path('<front>') }}\">
\t\t\t\t\t<img class=\"two--sc--img mb-3\" src=\"/themes/custom/atp/atp/assets/images/logo.png\"></a>


\t\t\t\t<p>{{\"Créer l'excellence architecturale à travers le Maroc et au-delà\" |t}}.</p>
\t\t\t\t{# {{ drupal_entity('block','atp_footer1') }} #}
\t\t\t</div>

\t\t\t<!-- Quick links -->
\t\t\t<div class=\"col-md-3 mb-4\">
\t\t\t\t<h6 class=\"mb-3\">{{'Liens rapides'|t}}</h6>
\t\t\t\t{# <ul class=\"list-unstyled\">
\t\t\t\t\t\t\t\t            <li><a href=\"#\" class=\"footer-link\">À propos</a></li>
\t\t\t\t\t\t\t\t            <li><a href=\"#\" class=\"footer-link\">Projets</a></li>
\t\t\t\t\t\t\t\t            <li><a href=\"#\" class=\"footer-link\">Carrières</a></li>
\t\t\t\t\t\t\t\t            <li><a href=\"#\" class=\"footer-link\">Contact</a></li>
\t\t\t\t\t\t\t\t          </ul> #}
\t\t\t\t{% if page.footer_top_2 %}
\t\t\t\t\t{{page.footer_top_2}}
\t\t\t\t{% endif %}
\t\t\t</div>

\t\t\t<!-- Contact information -->
\t\t\t<div
\t\t\t\tclass=\"col-md-3 mb-4 localed-icon\">
\t\t\t\t{# <h6 class=\"mb-3\">Informations de contact</h6>
\t\t\t\t\t\t\t\t          <p><i class=\"fa-solid fa-location-dot\"></i>Casablanca, Morocco</p>
\t\t\t\t\t\t\t\t          <p><i class=\"fa-solid fa-phone\"></i>+212 522 22 24 45</p>
\t\t\t\t\t\t\t\t          <p><i class=\"fa-solid fa-envelope\"></i>secretariat@agenceatp.com</p> #}
\t\t\t\t{{ drupal_entity('block','atp_footer3') }}
\t\t\t</div>

\t\t\t<!-- Social links -->
\t\t\t<div class=\"col-md-3 mb-4\">
\t\t\t\t<h6 class=\"mb-3\">{{'Suivez-nous'|t}}</h6>
\t\t\t\t<a href=\"#\" class=\"footer-social\">
\t\t\t\t\t<i class=\"fa-brands fa-linkedin\"></i>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"footer-social\">
\t\t\t\t\t<i class=\"fa-brands fa-instagram\"></i>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"footer-social\">
\t\t\t\t\t<i class=\"fa-brands fa-facebook\"></i>
\t\t\t\t</a>
\t\t\t\t{# {{ drupal_entity('block','atp_footer4') }} #}
\t\t\t</div>
\t\t</div>

\t\t<hr class=\"border-light\">

\t\t<div class=\"text-center\">
\t\t\t<small>{{'© 2025 Agence ATP. All rights reserved'|t}}.</small>
\t\t</div>
\t</div>
</footer>
{# <footer class=\"text-light py-5\">
\t<div class=\"container\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-12 mb-4\">
\t\t\t\t{{ drupal_entity('block','desktech_site_branding') }}
\t\t\t</div>

\t\t\t<div class=\"col-md-4\">
      {{ drupal_entity('block','desktech_footerleft') }}


\t\t\t</div>

\t\t\t<div class=\"col-md-4\">
 {{ drupal_entity('block','desktech_liensutiles') }}


\t\t\t</div>

\t\t\t<div class=\"col-md-4 last--list-foooter\">
\t\t\t\t<h3>Newsletter</h3>
\t\t\t\t<p>
\t\t\t\t\tAbonnez-vous pour recevoir les dernières nouveautés et offres exclusives Ricoh au Maroc.
\t\t\t\t</p>

        {{ drupal_entity('block','desktech_webform_3') }}
\t\t\t</div>

\t\t\t<div class=\"text-center mb-4 copyright--foooter mt-3\">
\t\t\t\t<hr class=\"line__footer\">
        {{ drupal_entity('block','desktech_copyright') }}
\t\t\t</div>

\t\t</div>


\t</div>
</footer> #}
", "@atp/partials/footer.html.twig", "C:\\laragon\\www\\atp\\themes\\custom\\atp\\templates\\partials\\footer.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 99];
        static $filters = ["t" => 86, "escape" => 100];
        static $functions = ["path" => 82, "drupal_entity" => 111];

        try {
            $this->sandbox->checkSecurity(
                ['if'],
                ['t', 'escape'],
                ['path', 'drupal_entity'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
